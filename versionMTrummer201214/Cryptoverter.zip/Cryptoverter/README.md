# Cryptoverter

* Introduction
Cryptoverter is a software application which was developed during the module of "Project management and software engineering" in the course "Electrical Engineering" at "University of applied Science OST Rapperswil".
The main purpose of this software is to encrypt and decrypt datasets with multiple kind of algorithms.

* How to use the software

  1. Insert your text or load from file
  2. Choose your encryption algorithm
  3. Set your password if required
  4. Click convert
  5. Copy the encrypted text from the textbox or save to file

Follow the same steps if you want to decrypt an encrypted file.
  
